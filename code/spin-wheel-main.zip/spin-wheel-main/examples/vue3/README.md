# spin-wheel-example-vue

This example was scaffolded using `npm create vue@latest`.

```sh
npm install

# Compile and Hot-Reload for Development
npm run dev

# Compile and Minify for Production
npm run build
```