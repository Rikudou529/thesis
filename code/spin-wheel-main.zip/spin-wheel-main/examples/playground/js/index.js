import './initWheel.js';
import './initEventListeners.js';

// Show the wheel once everything has loaded
document.querySelector('.wheel-wrapper').style.visibility = 'visible';